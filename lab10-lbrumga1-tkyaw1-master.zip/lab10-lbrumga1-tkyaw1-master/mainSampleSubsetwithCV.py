import numpy as np
from os import listdir as ls
import matplotlib.pyplot as plt
from scipy import ndimage
from PIL import Image
from numpy import argmax, zeros, logical_not

from keras.models import Sequential
from keras.layers import Conv2D, Dense, Dropout, MaxPooling2D, AveragePooling2D, Flatten

# TODO: load test file (if you want)
# NOTE: relu for non output layers, sigmoid for output layers ?? not sure y
# NOTE: adding another pair of pooling/conv layer dropped accuracy a lot

def settingItUp():
    neural_net = Sequential()

    neural_net.add(AveragePooling2D(pool_size=(2, 2), strides=None, padding='valid', input_shape = (500, 500, 3)))
    neural_net.add(Conv2D(128, (3, 3), activation = 'relu'))
    neural_net.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid'))

    neural_net.add(Conv2D(128, (3, 3), activation = 'relu'))
    neural_net.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid'))

    neural_net.add(Conv2D(64, (3, 3), activation = 'relu'))
    neural_net.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid'))

    neural_net.add(Flatten())
    neural_net.add(Dense(32, activation = 'relu'))
    neural_net.add(Dropout(0.5))
    neural_net.add(Dense(2, activation = 'sigmoid'))
    #neural_net.add(Dropout(0.2))
    neural_net.summary()

    neural_net.compile(optimizer="Adam", loss="categorical_crossentropy", metrics=['accuracy'])

    return neural_net

def train(xtrainfinal, ytrainfinal, neural_net):
    history = neural_net.fit(xtrainfinal, ytrainfinal, verbose=1, epochs=10)

def test(xtest, ytest, neural_net):
    """Reports the fraction of the test set that is correctly classified.

    The predict() keras method is run on each element of x_test, and the result
    is compared to the corresponding element of y_test. The fraction that
    are classified correctly is tracked and returned as a float.
    """
    loss, accuracy = neural_net.evaluate(xtest, ytest, verbose=0)
    return accuracy

def crossValidation():
    neural_net = settingItUp()
    folds = 5
    # files = []
    # labels = []
    # for j in range(40):
    #     files.append("/scratch/tkyaw1/sampleSubset" + str(j) + ".npz")
    #     labels.append("/scratch/tkyaw1/sampleLabels" + str(j) + ".npz")
    # files = np.array(files)
    # labels = np.array(labels)

    files1 = np.load("/scratch/tkyaw1/sampleSubset.npz")
    labels1 = np.load("/scratch/tkyaw1/sampleLabels.npz")

    files = files1['arr_0']
    labels = labels1['arr_0']

    percentlist = []
    for i in range(5):
        print "FOLD NUMBER:", i
        b = zeros(1000, dtype = bool)
        bcopy = b
        start = i*200
        end = (i+1) * 200
        bcopy[start:end] = True

        xtrain = files[logical_not(bcopy)]
        trainLabels = labels[logical_not(bcopy)]
        xtest = files[bcopy]
        testLabels = labels[bcopy]

        print "TRAINING in FOLD ", i
        train(xtrain, trainLabels, neural_net)

        foldAccs = []
        print "TESTING in FOLD ", i
        accuracy = test(xtest, testLabels, neural_net)
        # print "foldAcc:", foldAcc
        # foldAccs.append(foldAcc)
        #
        # accuracy = sum(foldAccs)/float(len(foldAccs))
        # print "Accuracy over entire fold", accuracy
        # #testing
        percentlist.append(accuracy)

    average = sum(percentlist)/float(len(percentlist))
    print "Final Average Accuracy Over 5 Folds", average

crossValidation()
